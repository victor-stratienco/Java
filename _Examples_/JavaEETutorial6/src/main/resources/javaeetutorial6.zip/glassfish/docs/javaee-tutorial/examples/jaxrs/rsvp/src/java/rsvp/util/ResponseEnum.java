/*
 * Copyright 2010 Oracle and/or its affiliates.
 * All rights reserved.  You may not modify, use,
 * reproduce, or distribute this software except in
 * compliance with  the terms of the License at:
 * http://developer.sun.com/berkeley_license.html
 */


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rsvp.util;


/**
 *
 * @author ian
 */
public enum ResponseEnum {
    ATTENDING,
    NOT_ATTENDING,
    MAYBE_ATTENDING,
    NOT_RESPONDED;
}
